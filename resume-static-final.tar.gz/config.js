/**
 * @copyright Tomda (https://www.tomda.top)
 * @copyright UIED技术团队 (https://fsuied.com)
 * @author UIED技术团队
 * @createDate 2025-1-27
 */

// AI功能配置
window.AI_CONFIG = {
  // 设置你的API密钥
  apiKey: 'sk-your-api-key-here',
  
  // API基础URL（通过反向代理）
  baseUrl: '/api/ai',
  
  // 默认模型
  model: 'deepseek-chat',
  
  // 是否启用AI功能
  enabled: true
};

// 性能监控配置
window.PERFORMANCE_CONFIG = {
  // 是否启用性能监控
  enabled: true,
  
  // 监控数据上报URL
  reportUrl: '/api/performance'
};